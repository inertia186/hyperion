class Api::V1::AgentAuthChallengesController < Api::V1::BaseController
  protect_from_forgery except: %i(create redeem keychain)
  skip_before_action :sign_in
  before_action :validate_agent_origin!, only: %i(create start redeem keychain)
  rescue_from ActiveRecord::RecordNotFound, with: :not_found

  def create
    render_new_challenge
  end

  def start
    render_new_challenge
  end

  def show
    challenge = AgentAuthChallenge.find_by!(token: params[:id])

    render json: challenge_status_payload(challenge)
  end

  def hivesigner_callback
    challenge = AgentAuthChallenge.find_available!(params[:state])

    if challenge.redeemed_at.present?
      render html: hivesigner_redeemed_html(challenge).html_safe
      return
    end

    if challenge.account_id.present? && challenge.verification_code_digest.present?
      render html: hivesigner_authorized_html(challenge).html_safe
      return
    end

    account = HivesignerAuthenticator.new(params[:access_token]).account

    unless account
      render plain: 'Hyperion could not verify this HiveSigner login.', status: :unauthorized
      return
    end

    code = challenge.authorize_for_copy_code!(account)
    render html: hivesigner_success_html(account, code, challenge).html_safe
  end

  def redeem
    challenge = AgentAuthChallenge.find_available!(params[:id])
    account = challenge.redeem!(params[:code])
    session[:current_account] = account

    render json: authenticated_payload(challenge, account)
  rescue ArgumentError => e
    render json: {error: e.message}, status: :unprocessable_entity
  end

  def keychain
    challenge = AgentAuthChallenge.find_available!(params[:id])

    unless params[:digest].to_s == challenge.keychain_digest
      render json: {error: 'Invalid challenge digest.'}, status: :unprocessable_entity
      return
    end

    unless HiveKeychainAuthenticator.valid_signature?(
      account_name: params[:account_name],
      public_key: params[:public_key],
      digest_hex: params[:digest],
      signature_hex: params[:signature]
    )
      render json: {error: 'Invalid Keychain signature.'}, status: :unauthorized
      return
    end

    account = Account.find_or_create_by!(name: params[:account_name])
    challenge.complete_keychain!(account)
    session[:current_account] = account

    render json: authenticated_payload(challenge, account)
  end

private
  def render_new_challenge
    challenge = AgentAuthChallenge.issue!

    render json: challenge_payload(challenge), status: :created
  end

  def challenge_payload(challenge)
    challenge_status_payload(challenge).merge(
      hivesigner_login_url: hivesigner_login_url(challenge),
      keychain: {
        message: challenge.keychain_message,
        digest: challenge.keychain_digest
      }
    )
  end

  def challenge_status_payload(challenge)
    {
      challenge_id: challenge.token,
      status: challenge_status(challenge),
      expires_at: challenge.expires_at.iso8601
    }
  end

  def authenticated_payload(challenge, account)
    _token_record, bearer_token = AgentAccessToken.issue_for!(account)

    {
      challenge_id: challenge.token,
      authenticated: true,
      token_type: 'Bearer',
      bearer_token: bearer_token,
      account: {
        id: account.id,
        name: account.name,
        avatar_url: "https://images.hive.blog/u/#{account.name}/avatar"
      }
    }
  end

  def challenge_status(challenge)
    return 'expired' if challenge.expired?
    return 'redeemed' if challenge.redeemed_at.present?
    return 'authorized' if challenge.account_id.present?

    'pending'
  end

  def hivesigner_login_url(challenge)
    "https://hivesigner.com/oauth2/authorize?#{URI.encode_www_form(hivesigner_authorize_params(challenge))}"
  end

  def hivesigner_authorize_params(challenge)
    {
      client_id: 'hyperion.zone',
      redirect_uri: hivesigner_callback_api_v1_agent_auth_challenges_url,
      scope: 'login',
      state: challenge.token
    }
  end

  def hivesigner_success_html(account, code, challenge)
    escaped_account = ERB::Util.html_escape(account.name)
    escaped_code = ERB::Util.html_escape(code)
    escaped_expires_at = ERB::Util.html_escape(challenge.expires_at.iso8601)

    <<~HTML
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Hyperion Agent Login</title>
        </head>
        <body>
          <main>
            <h1>Hyperion agent login</h1>
            <p>Signed in as <strong>#{escaped_account}</strong>.</p>
            <p>Copy this one-time code back to your agent:</p>
            <pre style="font-size: 2rem; font-weight: bold;">#{escaped_code}</pre>
            <p>This code expires at #{escaped_expires_at}.</p>
          </main>
        </body>
      </html>
    HTML
  end

  def hivesigner_authorized_html(challenge)
    escaped_expires_at = ERB::Util.html_escape(challenge.expires_at.iso8601)

    <<~HTML
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Hyperion Agent Login</title>
        </head>
        <body>
          <main>
            <h1>Hyperion agent login</h1>
            <p>This challenge is already authorized.</p>
            <p>Use the latest HYP-* code already shown for this challenge. Hyperion will not create a new code from a refreshed HiveSigner callback.</p>
            <p>This code expires at #{escaped_expires_at}.</p>
          </main>
        </body>
      </html>
    HTML
  end

  def hivesigner_redeemed_html(challenge)
    escaped_challenge_id = ERB::Util.html_escape(challenge.token)

    <<~HTML
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Hyperion Agent Login</title>
        </head>
        <body>
          <main>
            <h1>Hyperion agent login</h1>
            <p>This challenge has already been redeemed.</p>
            <p>Your agent should already have the Hyperion session cookie for challenge #{escaped_challenge_id}.</p>
          </main>
        </body>
      </html>
    HTML
  end

  def validate_agent_origin!
    return if request.origin.blank?

    origin = URI.parse(request.origin)
    return if origin.scheme == request.scheme && origin.host == request.host && origin.port == request.port

    render json: {error: 'Forbidden origin'}, status: :forbidden
  rescue URI::InvalidURIError
    render json: {error: 'Forbidden origin'}, status: :forbidden
  end

  def not_found
    render json: {error: 'Challenge not found or expired.'}, status: :not_found
  end
end
